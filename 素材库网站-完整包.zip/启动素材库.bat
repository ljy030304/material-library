@echo off
chcp 65001 >nul
echo ========================================
echo   信息流拍摄素材库 - 本地服务器
echo ========================================
echo.
echo 正在启动本地服务器...
echo.

REM 查找 Python
python --version >nul 2>&1
if %errorlevel% == 0 (
    echo [✓] 找到 Python
    start http://localhost:8080
    python -m http.server 8080
    goto end
)

python3 --version >nul 2>&1
if %errorlevel% == 0 (
    echo [✓] 找到 Python3
    start http://localhost:8080
    python3 -m http.server 8080
    goto end
)

REM 查找 Node.js
node --version >nul 2>&1
if %errorlevel% == 0 (
    echo [✓] 找到 Node.js
    echo 安装 serve...
    npm install -g serve
    start http://localhost:8080
    serve -l 8080
    goto end
)

echo [✗] 未找到 Python 或 Node.js
echo.
echo 请安装以下任一环境：
echo   1. Python (https://python.org)
echo   2. Node.js (https://nodejs.org)
echo.
pause

:end
