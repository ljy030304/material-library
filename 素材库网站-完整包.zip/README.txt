素材库网站 - 部署说明
========================

文件夹内容：
  - index.html          ← 网站主体文件
  - 启动素材库.bat      ← Windows 本地启动脚本

使用方法：

【方式一：部署到在线网站（推荐）】
1. 把整个文件夹压缩成 ZIP
2. 打开 https://app.netlify.com/drop
3. 把 ZIP 文件拖拽到网页上
4. 等待几秒，获得在线链接

【方式二：本地使用】
1. 双击 "启动素材库.bat"
2. 浏览器自动打开 http://localhost:8080
3. 只有本机能访问

【方式三：Surge.sh 部署（需 Node.js）】
1. 安装 Node.js：https://nodejs.org
2. 打开 cmd，进入此文件夹
3. 运行：npx surge
4. 按提示操作，获得在线链接
